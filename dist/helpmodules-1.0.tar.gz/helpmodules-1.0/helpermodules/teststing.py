import pandas as pd
import xlwings as xw
import os



excelSheetName = "Summary by Node (by DTE)"
excelFileName = "FY20 Leader PR and HC Plan_Area_AAPAC"
pathExcelName = os.path.relpath(f'spreadsheets/{excelFileName}.xlsb')
book = xw.Book(pathExcelName)
sheet = book.sheets(excelSheetName)

df = sheet.range('C18').options(pd.DataFrame, expand='table').value
#book.close()
book.app.kill()

print(df)
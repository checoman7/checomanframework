from setuptools import setup


setup(

    name="helpmodules",
    version="1.0",
    author= "Checoman",
    packages= ["helpermodules"]

)